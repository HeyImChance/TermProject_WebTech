(function(){
    var params = (window.location.hash.substr(1)).split("#");
    
    var app = angular.module('flights', []);
    app.controller('flightsController', ['$scope', function($scope) {
        
        var name = params[0];
        var email = params[1];
        var findItem = {"name":name,"email":email};
        $.post("getLogin",findItem,function(result){
            //var foundItem = result;
            console.log(result);
            var headers = document.createElement('h1');
            var headText = document.createTextNode("Tickets System Destination Ship");
            headers.appendChild(headText);
            document.body.appendChild(headers);
            for(i=0; i<result.length; i++){
                var paragraph = document.createElement('P');
                var tickets = document.createTextNode(result[i].tickets+" ");
                var system = document.createTextNode(result[i].system+" ")
                var destination = document.createTextNode(result[i].destination+" ");
                var ship = document.createTextNode(result[i].ship);
                paragraph.appendChild(tickets);
                paragraph.appendChild(system);
                paragraph.appendChild(destination);
                paragraph.appendChild(ship);
                document.body.appendChild(paragraph);
            }
               
            });
        }]);
    
}());