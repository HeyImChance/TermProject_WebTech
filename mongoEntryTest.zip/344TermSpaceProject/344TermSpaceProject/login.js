(function() {
	var app = angular.module('login', []);

	app.controller('LoginController', ['$scope', function($scope) {
		$scope.name = $scope.email = '';
		$scope.login = [];
		
		$scope.all = function() {
			$.getJSON('getMusician', function(result) {
					$scope.musicians = result;
			});
		};

		$scope.add = function() {
			var newLogin = {
				"name" : $scope.name,
				"email" : $scope.email
				
			};
            console.log(newLogin);
			$scope.login.push(newLogin);
			$.post('putLogin', newLogin);
		  $scope.name = $scope.email = '';
		};
		
		$scope.update = function() {
			var updateLogin = { "name" : $scope.name, "email" : $scope.email};
			$.post('updateLogin', updateLogin);
			$scope.name = $scope.email = '';
		};
		
		$scope.remove = function(login) {
			$scope.login.splice($scope.login.indexOf(login), 1);
			$.post('removeLogin', login);
		};									 
	}]);
}());
