(function () {
	"use strict";
	
	var express = require('express'),
			bodyParser = require('body-parser'),
			mongoose = require('mongoose'),
			app = express();
	mongoose.Promise = global.Promise;

	app.use(express.static(__dirname));
	app.use(bodyParser.urlencoded({ extended: true }));
	
	mongoose.connect('mongodb://localhost/loginStuff');
	
	var LoginSchema = mongoose.Schema({
		"name": String,
		"email": String,
		
	});
	var Login = mongoose.model('Login', LoginSchema);
	
	app.use(function(req, res, next) {
  	console.log('%s %s', req.method, req.url);
		next();
	});
	
	app.get("/getLogin", function(req, res) {
		
		Login.find(req.query, function(err, login) {
			if (err) {
				console.log(err);
			} else {
				console.log(login);
				res.json(login);
			}		
		});

	});
	
	app.post("/putLogin", function(req, res) {
		var newLogin = new Login(req.body);
        console.log(req.body);
		newLogin.save(function(error, data) {
			if (error) console.log(error); 
		});
	});
	
	app.post("/updateLogin", function(req, res) {
		var conditions = {"name" : req.body.name};
		var update = {$set : {"email" : req.body.email}};
		Login.update(conditions, update, {multi : false}, function(error, result) {
			if (error) console.log(error);
		});
		res.end();
	});
	
	app.post("/removeLogin", function(req, res) {
		var oldLogin = new Login(req.body);
		oldLogin.remove(function(error, data) {
			if (error) console.log(error);
		});
	});

	app.listen(3000);
	console.log("Server listening on port 3000."); 

}());