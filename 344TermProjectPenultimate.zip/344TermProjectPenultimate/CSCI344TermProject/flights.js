(function(){
    var params = (window.location.hash.substr(1)).split("#");
    
    var app = angular.module('flights', []);
    app.controller('flightsController', ['$scope', function($scope) {
        
        var name = params[0];
        var email = params[1];
        var findItem = {"name":name,"email":email};
        $.post("getLogin",findItem,function(result){
            //var foundItem = result;
            console.log(result);
            var headers = document.createElement('h1');
            var header2 = document.createElement('h2');
            var firstText = document.createTextNode('Your Ticket Information:')
            var headText = document.createTextNode("Tickets -  System - Destination - Ship");
            headers.appendChild(firstText);
            header2.appendChild(headText);
            document.body.appendChild(headers);
            document.body.appendChild(header2);
            for(i=0; i<result.length; i++){
                var paragraph1 = document.createElement('p1');
                var tickets = document.createTextNode(result[i].tickets+" ");
                var paragraph2 = document.createElement('p2');
                var system = document.createTextNode(result[i].system+" ");
                var paragraph3 = document.createElement('p3');
                var destination = document.createTextNode(result[i].destination+" ");
                var paragraph4 = document.createElement('p4');
                var ship = document.createTextNode(result[i].ship);
                paragraph1.appendChild(tickets);
                paragraph2.appendChild(system);
                paragraph3.appendChild(destination);
                paragraph4.appendChild(ship);
                document.body.appendChild(paragraph1);
                 document.body.appendChild(paragraph2);
                 document.body.appendChild(paragraph3);
                 document.body.appendChild(paragraph4);
            }
               
            });
        }]);
    
}());