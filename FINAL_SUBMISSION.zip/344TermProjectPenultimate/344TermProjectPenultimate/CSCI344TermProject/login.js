(function() {
	var app = angular.module('login', []);
	app.controller('LoginController', ['$scope', function($scope) {
		$scope.name = $scope.email = $scope.tickets = $scope.system = $scope.destination = $scope.ship = '';
       $scope.systems = [
            {
            name:"Inner Solar System",
            destinations:[
                            {name:"Mercury",distance:0.61},
                            {name:"Venus",distance:0.28},
                            {name:"Earth's Moon",distance:0.00257},
                            {name:"Mars",distance:0.52},
                            {name:"Jupiter",distance:4.2},
                            {name:"Saturn",distance:8.58}
                         ],
            distanceScale:"Astronomical Units",
            ships:["The Black Pearl","Tired of these motherf*&%# klingons on this mother&*#& shuttle","The Ark (bow chicka wow-wow)"],
            model:"Mach 100k Cruiser",
            distRate:102,
            surplas:200,
            speed:0.1,
            conv:0.139,
            delay:0.25
            },
            {
            name:"Outer Solar System",
            destinations:[
                            {name:"Uranus",distance:18.2},
                            {name:"Neptune",distance:29},
                            {name:"Pluto",distance:38.5},
                            {name:"Planet9",distance:669}
                         ],
            distanceScale:"Astronomical Units",
            ships:["Titanic 2","Magic Carpet","(she wants)The Moby D"],
            model:"Mach 500k Cruiser",
            distRate:47,
            surplas:350,
            speed:0.6,
            conv:0.139,
            delay:0.25
            },
            {
            name:"Intergalactic",
            destinations:[
                            {name:"Proxima Centauri b",distance:3.8},
                            {name:"J1407b - Super Saturn",distance:430},
                            {name:"Orion Nebula Tour",distance:1350},
                            {name:"Kepler-64b",distance:5006},
                            {name:"Pistol Star",distance:24645},
                            {name:"Sagittarius A",distance:25071}
                          ],
            ships:["United (seats not guaranteed)","I'm on a boat, mother%#$@","The Enterprise"],
            distanceScale:"Light Years",
            model:"GigaMach Cruiser",
            distRate:3.5,
            surplas:1000,
            speed:1000000,
            conv:8760,
            delay:0.25
            },
            {
            name:"Extragalactic",
            destinations:[
                            {name:"Local Group Tour",distance:2.5},
                            {name:"Virgo Supercluster Tour",distance:35},
                            {name:"The Dinosaur Extinction",distance:65},
                            {name:"Quasar Tour",distance:5346}
                        ],
            distanceScale:"Million Light Years",
            ships:["SS Rick Sanchez","The Death Star","The Restaurant at the End of the Universe"],
            model:"Mach 100k Cruiser+",
            distRate:250,
            surplas:10000,
            speed:0.1,
            conv:0,
            delay:0.25
            }
        ];
		$scope.login = [];
            
        $scope.formula = function(system,dest){
            return Number.parseInt(system.distRate * Math.sqrt(dest.distance) + system.surplas) * $scope.tickets;
        }
        
        $scope.timeFormula = function(system,dest){
            return (((dest.distance * system.conv) / system.speed) + system.delay).toFixed(2)
        }
            
        $scope.showFlights = function() {
            var name = $scope.name;
            var email = $scope.email;
            window.open("/showFlights.html#"+name+'#'+email);
            //window.location.assign = "showFlights.html";// + '#' + text;
            /*
            var name = $scope.name;
            var email = $scope.email;
            var findItem = {"name":name,"email":email};
            $.post("getLogin",findItem,function(result){
                var foundItem = result[0];
                console.log(foundItem);
               
            });
            */
        };
        
        /*
        $('#showFlights').on('click', function() {
		console.log("retrieve clicked");
		var name = $('#name').val();
        var email = $('#email').val();
        var findItem = {"name": name, "email": email};
		$.post("getLogin", findItem, function(result) {
			var foundItem = result[0];
			$('#ticks').val(foundItem.tickets);
			$('#systs').val(foundItem.system.name);
			$('#dests').val(foundItem.destination);
            $('#ships').val(foundItem.ship);
            console.log(foundItem);
		});
	   });
        */
        
        
		$scope.add = function() {
			var newLogin = {
				"name" : $scope.name,
				"email" : $scope.email,
                "tickets" : $scope.tickets,
                "system" : $scope.system.name,
                "destination" : $scope.destination.name,
                "ship" : $scope.ship
			};
            console.log(newLogin);
            
			$scope.login.push(newLogin);
			$.post('putLogin', newLogin);
		  $scope.name = $scope.email = $scope.tickets = $scope.system = $scope.destination = $scope.ship = '';
		};
		
		$scope.update = function() {
			var updateLogin = { "name" : $scope.name, "email" : $scope.email};
			$.post('updateLogin', updateLogin);
			$scope.name = $scope.email = '';
		};
		
		$scope.remove = function(login) {
			$scope.login.splice($scope.login.indexOf(login), 1);
			$.post('removeLogin', login);
		};
	}]);
}());
