(function() {
	var app = angular.module('login', []);
	app.controller('LoginController', ['$scope', function($scope) {
		$scope.name = $scope.email = $scope.tickets = $scope.system = $scope.destination = $scope.ship = '';
        $scope.systems = [
            {
            name:"Inner Solar System",
            destinations:["Mercury","Venus","Earth's Moon",
                         "Mars","Jupiter","Saturn"],
            ships:["The Black Pearl","Tired of these motherf*&%# klingons on this mother&*#& shuttle","The Ark (bow chicka wow-wow)"]
            },
            {
            name:"Outer Solar System",
            destinations:["Uranus","Pluto","Neptune","Eris","Haumea","Planet9"],
            ships:["Titanic 2","Magic Carpet","(she wants) The Moby D"]
            },
            {
            name:"Intergalactic",
            destinations:["TRAPPIST-1","Proxima Centauri b","Cygnus-X1","Sagittarius A","Pistol Star","Orion Nebula Tour","J1407b - Super Saturn",
                "Kepler-64b"],
            ships:["United (seats not guaranteed)","I'm on a boat, mother%#$@","The Enterprise"]
            },
            {
            name:"Extragalactic",
            destinations:["The Dinosaur Extinction","Quasar Tour","Local Group Tour","Virgo Supercluster Tour"],
            ships:["SS Rick Sanchez","The Death Star","The Restaurant at the End of the Universe"]
            }
        ];
		$scope.login = [];
            
        $scope.showFlights = function() {
            var name = $scope.name;
            var email = $scope.email;
            window.open("/showFlights.html#"+name+'#'+email, "_blank");
            //window.location.assign = "showFlights.html";// + '#' + text;
            /*
            var name = $scope.name;
            var email = $scope.email;
            var findItem = {"name":name,"email":email};
            $.post("getLogin",findItem,function(result){
                var foundItem = result[0];
                console.log(foundItem);
               
            });
            */
        };
        
        /*
        $('#showFlights').on('click', function() {
		console.log("retrieve clicked");
		var name = $('#name').val();
        var email = $('#email').val();
        var findItem = {"name": name, "email": email};
		$.post("getLogin", findItem, function(result) {
			var foundItem = result[0];
			$('#ticks').val(foundItem.tickets);
			$('#systs').val(foundItem.system.name);
			$('#dests').val(foundItem.destination);
            $('#ships').val(foundItem.ship);
            console.log(foundItem);
		});
	   });
        */
        
        
		$scope.add = function() {
			var newLogin = {
				"name" : $scope.name,
				"email" : $scope.email,
                "tickets" : $scope.tickets,
                "system" : $scope.system.name,
                "destination" : $scope.destination,
                "ship" : $scope.ship
			};
            console.log(newLogin);
            
			$scope.login.push(newLogin);
			$.post('putLogin', newLogin);
		  $scope.name = $scope.email = $scope.tickets = $scope.system = $scope.destination = $scope.ship = '';
		};
		
		$scope.update = function() {
			var updateLogin = { "name" : $scope.name, "email" : $scope.email};
			$.post('updateLogin', updateLogin);
			$scope.name = $scope.email = '';
		};
		
		$scope.remove = function(login) {
			$scope.login.splice($scope.login.indexOf(login), 1);
			$.post('removeLogin', login);
		};
	}]);
}());
